function setup() {
  createCanvas(windowWidth, windowHeight);
}


var mode = 'STAR';



function draw() {
  background(0);
  randomSeed(0);
  stroke(255);

  var x, y, r;
  var delta = map(mouseX, 0, windowWidth, 30, 100);
  var backSlashThickness = map(mouseY, 0, windowHeight,
    3, 12);


  for (y = 0; y < windowHeight; y += delta) {
    for (x = 0; x < windowWidth; x += delta) {

      r = random(0, 1);

      if (r < 0.5) {
        fill(243, random(240, 255), 0);

        switch (mode) {
          case 'STAR':
            //line  
            stroke(random(0, 255));
            strokeWeight(2);
            line(x, y, x + delta, y + delta);
            //line2
            stroke(random(0, 255));
            strokeWeight(random(0, backSlashThickness));
            line(x, y, x + delta, y + delta);

            //star
            stroke(255);
            strokeWeight(2);
            beginShape();
            vertex(x + 0, y - 5);
            vertex(x + 1.4, y - 2);
            vertex(x + 4.7, y - 1.5);
            vertex(x + 2.3, y + 0.7);
            vertex(x + 2.9, y + 4);
            vertex(x + 0, y + 2.5);
            vertex(x - 2.9, y + 4.0);
            vertex(x - 2.3, y + 0.7);
            vertex(x - 4.7, y - 1.5);
            vertex(x - 1.4, y - 2.0);
            endShape(CLOSE);

            break;
            
            
          case 'LINE':
            stroke(random(0, 255),random(0, 255),random(0, 255));
            strokeWeight(random(0, backSlashThickness));
            line(x + delta, y, x, y + delta);
            
            //star
            stroke(255);
            strokeWeight(3);
            beginShape();
            vertex(x + 0, y - 5);
            vertex(x + 1.4, y - 2);
            vertex(x + 4.7, y - 1.5);
            vertex(x + 2.3, y + 0.7);
            vertex(x + 2.9, y + 4);
            vertex(x + 0, y + 2.5);
            vertex(x - 2.9, y + 4.0);
            vertex(x - 2.3, y + 0.7);
            vertex(x - 4.7, y - 1.5);
            vertex(x - 1.4, y - 2.0);
            endShape(CLOSE);
            
            
            
            
            
            
            break;
        }
      }
    }
  }
}

function keyPressed() {
  switch (key) {

    case '1':
      mode = "STAR";
      break;
    case '2':
      mode = "LINE";
      break;
    default:
      mode = "NONE";
  }
  print(mode);
}